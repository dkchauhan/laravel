</div>
    </div>
  </div>
  <!-- End of Tab panes from left menu -->
</div>
</div>
				<!-- END OF RIGHT CPNTENT -->
			
			<div class="clearfix"></div><br/><br/>
			</div>
			<!-- END CONTENT -->			
			
	
	</div>
<div class="masternotice none">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  Message from TitanicThemes </div>
<!-- This page JS -->
{{ HTML::script('travel/assets/js/js-index.js') }}	
{{ HTML::script('travel/assets/js/js-dashboard.js') }}	
<!-- Sparkline -->
{{ HTML::script('travel/assets/js/jquery.sparkline.js') }}	
<!-- Custom functions -->
{{ HTML::script('travel/assets/js/functions.js') }}	
<!-- Counter -->
{{ HTML::script('travel/assets/js/counter.js') }}	
<!-- Picker UI-->
{{ HTML::script('travel/assets/js/jquery-ui.js') }}	
<!-- Easing -->
{{ HTML::script('travel/assets/js/jquery.easing.js') }}	
<!-- Nicescroll  -->
{{ HTML::script('travel/assets/js/jquery.nicescroll.min.js') }}	
<!-- CarouFredSel -->
{{ HTML::script('travel/assets/js/jquery.carouFredSel-6.2.1-packed.js') }}	
{{ HTML::script('travel/assets/js/helper-plugins/jquery.touchSwipe.min.js') }}	
{{ HTML::script('travel/assets/js/helper-plugins/jquery.mousewheel.min.js') }}	
{{ HTML::script('travel/assets/js/helper-plugins/jquery.transit.min.js') }}	
{{ HTML::script('travel/assets/js/helper-plugins/jquery.ba-throttle-debounce.min.js') }}	
<!-- Custom Select -->
{{ HTML::script('travel/assets/js/jquery.customSelect.js') }}	
<!-- Include all compiled plugins (below), or include individual files as needed -->
{{ HTML::script('travel/dist/js/bootstrap.min.js') }}	