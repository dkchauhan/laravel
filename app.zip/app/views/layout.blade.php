<html>
    <body>
        <h1>Hotel affiliate portal</h1>

        @yield('content')
    </body>
</html>