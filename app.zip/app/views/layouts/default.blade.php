<!DOCTYPE html>
<html>
  <head>
@include('includes.head')
  </head>
  <body>
    
	@yield('content')
	
  </body>
</html>
