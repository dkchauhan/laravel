<!DOCTYPE html>
<html>
  <head>
@include('includes.head')
  </head>
  <body id="top" class="thebg">
	@yield('content')
  </body>
</html>
