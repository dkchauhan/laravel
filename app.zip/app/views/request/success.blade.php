@extends('layouts.request')
 
@section('title') Create User @stop
 
@section('content')
 
<div class='col-lg-4 col-lg-offset-4'>
 
 <div class='form-group'>
        <p>Thank You For Your Enquiry</p>
    </div>
    
 
</div>
 
@stop